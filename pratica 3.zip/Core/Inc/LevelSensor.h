/*
 * LevelSensor.h
 *
 *  Created on: 3 de jul. de 2026
 *      Author: samar
 */

#ifndef INC_LEVELSENSOR_H_
#define INC_LEVELSENSOR_H_



#endif /* INC_LEVELSENSOR_H_ */

/*
 * Bsp.c
 *
 *  Created on: 3 de jul. de 2026
 *      Author: samar
 */


